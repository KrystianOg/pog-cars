//use .env file
require('dotenv').config();

/*
var AuthenticationClient = require('auth0').AuthenticationClient;

var auth0 = new AuthenticationClient({
    domain: '{YOUR_ACCOUNT}.auth0.com',
    clientId: '{OPTIONAL_CLIENT_ID}',
  });
*/

//ten install na dole jest ok
  //npm install express express-openid-connect --save 
//const auth0 = require('auth0-js');